from popelines.main import popeline
from pkg_resources import get_distribution

name = 'popelines'

__version__ = get_distribution("popelines").version